import java.util.*;

class IndexMain{
  public static void main(String[] args) {
    Empresa empresa = new Empresa();
    Scanner escrever = new Scanner(System.in);
    Funcoes funcao = new Funcoes();
    int x, stop = 0, stop1 = 0, pause = 1, y = 0;

    //3 funcionarios já criados para teste
    Funcionarios x1 = new Funcionarios("Cleisson", "8034761", "10254323508", "988199444", 1500.0);
    empresa.contrata(x1);
    Funcionarios x2 = new Funcionarios("Vitor", "7563623", "10559823509", "988145763", 1500.0);
    empresa.contrata(x2);
    Funcionarios x3 = new Funcionarios("Jamili", "9039122", "10354673510", "988789542", 1500.0);
    empresa.contrata(x3);

    //2 bebida já criadas pra teste
    Bebida z1 = new Bebida("José Cuervo", "49", "1000", 150.0, 10);
    empresa.cadastra(z1);
    Bebida z2 = new Bebida("Raiska", "15", "1000", 50.0, 20);
    empresa.cadastra(z2);

    //2 clientes já cadastrados pra teste
    Clientes w1 = new Clientes("Wallace", "10345223409", true);
    empresa.cadastraclientes(w1);
    Clientes w2 = new Clientes("Yakusa", "10981273405", false);
    empresa.cadastraclientes(w2);

    do{
      funcao.limpaTela();
      funcao.IndexMenuMain();
      System.out.printf("\n ---> ");
      x = escrever.nextInt();
      switch(x){
        case 1: funcao.limpaTela();
                System.out.println("CADASTRANDO FUNCIONÁRIO");
                Funcionarios novo = new Funcionarios();
                System.out.printf("Nome: ");
                novo.name = escrever.next();
                System.out.printf("RG: ");
                novo.rg = escrever.next();
                System.out.printf("CPF: ");
                novo.cpf = escrever.next();
                System.out.printf("Telefone: ");
                novo.phone = escrever.next();
                System.out.printf("Salario: ");
                novo.salario = escrever.nextDouble();
                empresa.contrata(novo);
                break;

        case 2: novo = new Funcionarios();
                System.out.println("\nFUNCIONARIOS CADASTRADOS:");
                empresa.mostrar(novo);
                System.out.printf("\n\n0 - Voltar ao menu...");
                pause = escrever.nextInt();
                break;

        case 3: funcao.limpaTela();
                System.out.println("CADASTRANDO CLIENTES");
                Clientes novocliente = new Clientes();
                System.out.printf("Nome: ");
                novocliente.name = escrever.next();
                System.out.printf("CPF: ");
                novocliente.cpf = escrever.next();
                System.out.printf("Permissão para vender fiado? |(1)SIM| |(2)NÃO| : ");
                y = escrever.nextInt();
                if(y == 1){
                  novocliente.venderFiado = true;
                }else if(y == 2){
                  novocliente.venderFiado = false;
                }
                empresa.cadastraclientes(novocliente);
                break;

        case 4: Clientes listaclientes = new Clientes();
                System.out.println("\nCLIENTES CADASTRADOS:");
                empresa.mostrarclientes(listaclientes);
                System.out.printf("\n\n0 - Voltar ao menu...");
                pause = escrever.nextInt();
                break;

        case 5: do{
                   funcao.limpaTela();
                   funcao.IndexMenuBebidas();
                   System.out.printf("\n ---> ");
                   x = escrever.nextInt();
                   switch(x){
                     case 1: funcao.limpaTela();
                             Bebida novabebida = new Bebida();
                             System.out.println("CADASTRANDO BEBIDA");
                             System.out.printf("Nome: ");
                             novabebida.name = escrever.next();
                             System.out.printf("Teor Alcóolico: ");
                             novabebida.teoralcoolico = escrever.next();
                             System.out.printf("Quantidade da garrafa (ml): ");
                             novabebida.ml = escrever.next();
                             System.out.printf("Preço: ");
                             novabebida.preco = escrever.nextDouble();
                             System.out.printf("Quantidade em estoque: ");
                             novabebida.qtdestoque = escrever.nextInt();
                             empresa.cadastra(novabebida);
                             break;

                     case 2: novabebida = new Bebida();
                             System.out.println("\nBEBIDAS CADASTRADAS:");
                             empresa.mostrarbebida(novabebida);
                             System.out.printf("\n\n0 - Voltar ao menu...");
                             pause = escrever.nextInt();
                             break;

                     case 3: novabebida = new Bebida();
                             System.out.println("\nCOMPRAR BEBIDAS");
                             empresa.encontrabebida(novabebida, 5);
                             funcao.limpaTela();
                             System.out.printf("\n\nCompra realizada com sucesso!\n0 - Voltar ao menu...");
                             pause = escrever.nextInt();
                             break;

                     case 4: novabebida = new Bebida();
                             System.out.println("\nVENDER BEBIDAS");
                             empresa.encontrabebida(novabebida, 10);
                             pause = escrever.nextInt();
                             break;

                     case 5: stop1 = 10; break;
                   }
                 }while(stop1 != 10);
                 break;

        case 6: stop = 11; break;
      }
    }while(stop != 11);


  }
}
