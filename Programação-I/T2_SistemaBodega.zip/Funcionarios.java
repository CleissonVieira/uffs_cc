class Funcionarios{
  String name;
  String rg;
  String cpf;
  String phone;
  Double salario;
  int id;

  public Funcionarios(String name, String rg, String cpf, String phone, Double salario){
    //"This." pega atributo da classe e (ex)"= name" pega paramêtros da main
    this.name = name;
    this.rg = rg;
    this.cpf = cpf;
    this.phone = phone;
    this.salario = salario;
  }

  public Funcionarios(){
  //Após criar um método construtor com parametros, criar outro sem para questão de "= new nameclass();" na main
  }
}
