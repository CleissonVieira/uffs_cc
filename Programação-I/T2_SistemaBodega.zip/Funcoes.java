class Funcoes{
  void IndexMenuMain(){
    System.out.println("BODEGA");
    System.out.println("1 - Cadastrar Funcionarios: " );
    System.out.println("2 - Listar todos os Funcionarios: " );
    System.out.println("3 - Cadastrar Cliente: " );
    System.out.println("4 - Listar todos os Clientes: " );
    System.out.println("5 - MENU BEBIDAS: " );
    System.out.println("6 - Sair:" );
  }

  void IndexMenuBebidas(){
    System.out.println("BEBIDAS");
    System.out.println("1 - Cadastrar Bebidas: " );
    System.out.println("2 - Listar Bebidas Cadastradas: " );
    System.out.println("3 - Comprar: " );
    System.out.println("4 - Vender: " );
    System.out.println("5 - Sair:" );
  }

  void limpaTela(){
    for (int i = 0; i < 30; ++i)
        System.out.println ();
  }

}
