import java.util.*;

class Empresa{
  String name;
  String cnpj;
  int nfuncionarios = 0, nbebidas = 0, nclientes = 0, id, compvend;
  boolean confirm;
  Funcoes funcao = new Funcoes();
  List<Funcionarios> bodegueiros = new ArrayList<>();
  List<Bebida> bebesdabodega = new ArrayList<>();
  List<Clientes> clientesbodegueiros = new ArrayList<>();
  Scanner escrever = new Scanner(System.in);



  public Empresa(){

  }

  void contrata(Funcionarios x){
    x.id = nfuncionarios;
    nfuncionarios++;
    bodegueiros.add(x);
  }

  void mostrar(Funcionarios x){
    Iterator<Funcionarios> i = bodegueiros.iterator();
    while(i.hasNext()){
      x = i.next();
      System.out.println("\nNome: " + x.name);
      System.out.println("RG: " + x.rg);
      System.out.println("CPF: " + x.cpf);
      System.out.println("Telefone: " + x.phone);
      System.out.println("Salario: R$ " + x.salario);
      System.out.println("ID: " + x.id);
    }
  }

  void cadastra(Bebida x){
    x.id = nbebidas;
    nbebidas++;
    bebesdabodega.add(x);
  }

  void mostrarbebida(Bebida x){
    Iterator<Bebida> i = bebesdabodega.iterator();
    while(i.hasNext()){
      x = i.next();
      System.out.println("\nNome da bebida: " + x.name);
      System.out.println("Teor alcóolico: " + x.teoralcoolico + "%");
      System.out.println("Quantidade da garrafa: " + x.ml + "ml");
      System.out.println("Preço: R$" + x.preco);
      System.out.println("Quantidade em estoque: " + x.qtdestoque);
      System.out.println("ID: " + x.id);
    }
  }


  void encontrabebida(Bebida x, int cv){
    mostrarbebida(x);
    if(cv == 10){
      System.out.printf("\n\nID da bebida que deseja vender: ");
      id = escrever.nextInt();
      System.out.printf("\nQuantidade de unidades da venda: ");
      compvend = escrever.nextInt();
    }else{
      System.out.printf("\n\nID da bebida que deseja comprar: ");
      id = escrever.nextInt();
      System.out.printf("\nQuantidade de unidades da comprar: ");
      compvend = escrever.nextInt();
    }
    Iterator<Bebida> y = bebesdabodega.iterator();
    while(y.hasNext()){
      x = y.next();
      if(x.id == id){
        if(cv == 10){
          confirm = x.confereEstoque(confirm, compvend);
          System.out.printf("Confirm: " + confirm);
          if(confirm == true){
            x.vender(compvend);
            funcao.limpaTela();
            System.out.printf("Venda realizada com Sucesso!\n0 - Voltar ao menu...");
            break;
          }
          funcao.limpaTela();
          System.out.printf("Estoque insuficiente...\n0 - Voltar ao menu...");
          break;
        }
        x.comprar(compvend);
        break;
      }
    }
  }


  void cadastraclientes(Clientes x){
    x.id = nclientes;
    nclientes++;
    clientesbodegueiros.add(x);
  }

  void mostrarclientes(Clientes x){
    Iterator<Clientes> z = clientesbodegueiros.iterator();
    while(z.hasNext()){
      x = z.next();
      System.out.println("\nCliente: " + x.name);
      System.out.println("CPF: " + x.cpf);
      System.out.println("Permissão para comprar fiado: " + x.venderFiado);
    }
  }
}
