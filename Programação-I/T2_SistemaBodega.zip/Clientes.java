class Clientes{
  String name;
  String cpf;
  boolean venderFiado;
  int id;


  public Clientes(String name, String cpf, boolean venderFiado){
    this.name = name;
    this.cpf = cpf;
    this.venderFiado = venderFiado;
  }

  public Clientes(){

  }
}
