class Bebida{
  String name;
  String teoralcoolico;
  String ml;
  Double preco;
  int qtdestoque, id;

  public Bebida(String name, String teoralcoolico, String ml, Double preco, int qtdestoque){
    //"This." pega atributo da classe e (ex)"= name" pega paramêtros da main
    this.name = name;
    this.teoralcoolico = teoralcoolico;
    this.ml = ml;
    this.preco = preco;
    this.qtdestoque = qtdestoque;
  }

  public Bebida(){

  }

  void comprar(int estoque){
    this.qtdestoque += estoque;
  }

  void vender(int estoque){
    this.qtdestoque -= estoque;
  }

  boolean confereEstoque(boolean confirm, int estoque){
    if(this.qtdestoque >= estoque){
      confirm = true;
    }else{
      confirm = false;
    }
    return confirm;
  }

  void mostra(){
    System.out.printf("BEBIDAS");
    System.out.printf("Nome: ");
    System.out.printf("Teor Alcoolico: ");
    System.out.printf("Quantidade em ml: ");
    System.out.printf("Preço: ");
    System.out.printf("Quantidade em estoque: ");
  }

}
