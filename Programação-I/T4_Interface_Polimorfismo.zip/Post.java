import java.util.Date;

public class Post {
    private String title;
    private Date date;
    private String content;
    private int likes;
    private int dislikes;

    public Post(){

    }

    void setDate(Date date){
        this.date = date;
    }

    Date getDate(){
        return this.date;
    }

    void setTitle(String title){
        this.title = title;
    }

    String getTitle(){
        return this.title;
    }

    void setContent(String content){
        this.content = content;
    }

    String getContent(){
        return this.content;
    }

    void setLikes(int likes){
        this.likes = likes;
    }

    int getLikes(){
        return this.likes;
    }

    void setDislikes(int dislikes){
        this.dislikes = dislikes;
    }

    int getDislikes(){
        return this.dislikes;
    }

    public void show(){
        System.out.println("Título: " + this.title);
        System.out.println("Data: " + this.date);
        System.out.println("Conteúdo: " + this.content);
        System.out.println("Curtidas: " + this.likes);
        System.out.println("Não curtidas: " + this.dislikes);
    }

    public void like(){
        this.likes++;
    }

    public void dislike(){
        this.dislikes++;
    }
}