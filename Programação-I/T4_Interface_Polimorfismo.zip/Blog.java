import java.util.*;
import java.util.Date;

public class Blog {
    List<Post> posts = new ArrayList<>();
    Scanner escrever = new Scanner(System.in);
    Funcoes funcao = new Funcoes();

    public void LikeorDis(int casos){
        Post w = new Post();
        System.out.printf("Índice do Post: ");
        int id = escrever.nextInt();
        if (casos == 5) {
            w = posts.get(id);
            w.like();
        } else if (casos == 6) {
            w = posts.get(id);
            w.dislike();
        }
    }

    public void showAll(int id){
        Post w = new Post();
        Iterator<Post> i = posts.iterator();
        while (i.hasNext()) {
            w = i.next();
            funcao.separa();
            System.out.println("Indíce: " + (id++));
            w.show();
        }
    }

    public void readData(Post p){
        if(p instanceof News){//notícia]
            News t = new News();
            System.out.printf("Título: ");
            t.setTitle(escrever.next());
            t.setDate(new Date(System.currentTimeMillis()));
            System.out.printf("Conteúdo: ");
            t.setContent(escrever.next());
            System.out.printf("Fonte: ");
            t.setSource(escrever.next());
            posts.add(t);
        }else if(p instanceof ProductReview){//resenha
            ProductReview t = new ProductReview();
            System.out.printf("Título: ");
            t.setTitle(escrever.next());
            t.setDate(new Date(System.currentTimeMillis()));
            System.out.printf("Conteúdo: ");
            t.setContent(escrever.next());
            System.out.printf("Marca: ");
            t.setBrand(escrever.next());
            System.out.printf("Avaliação (1 a 10): ");
            t.evaluate(escrever.nextInt());
            posts.add(t);
        }else if(p instanceof Post){//genérica
            System.out.printf("Título: ");
            p.setTitle(escrever.next());
            p.setDate(new Date(System.currentTimeMillis()));
            System.out.printf("Conteúdo: ");
            p.setContent(escrever.next());
            posts.add(p);
        }
    }

    public static void main(String[] args) {
        Scanner escrever = new Scanner(System.in);
        Funcoes funcao = new Funcoes();
        Blog blog = new Blog();
        int x, id;   
        do {
            funcao.limpaTela();
            funcao.IndexMenuMain();
            x = escrever.nextInt();
            switch (x) {
            case 1:
                News noticia = new News();
                blog.readData(noticia);
                break;
            case 2:
                ProductReview resenha = new ProductReview();
                blog.readData(resenha);
                break;
            case 3:
                Post generico = new Post();
                blog.readData(generico);
                break;
            case 4:
                id = 0;
                blog.showAll(id);
                funcao.separa();
                funcao.pause();
                break;
            case 5:
                blog.LikeorDis(x);
                break;
            case 6:
                blog.LikeorDis(x);
                break;
            }    
        } while (x != 0);
    }
}