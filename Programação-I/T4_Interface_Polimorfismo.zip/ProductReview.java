public class ProductReview extends Post implements Evaluable {
    private String brand;
    private int stars;

    public ProductReview(){
        super();
    }
    
    public ProductReview(String brand, int stars) {
        super();
        this.brand = brand;
        this.stars = stars;
    }

    void setBrand(String brand){
        this.brand = brand;
    }
    
    String getBrand(){
        return this.brand;
    }

    int getStars(){
        return this.stars;
    }

    public void show() {
        super.show();
        System.out.println("Marca: " + this.brand);
        System.out.println("Estrelas: " + this.stars);
    }
    //vai ser o set do start que recebe valor de 1 a 10
    public void evaluate(int value){
        this.stars = value;
    }
}