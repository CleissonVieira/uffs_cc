import java.util.*;

public class Date {
    Random x = new Random();
    public int dia;
    public int mes;
    public int ano;

    int getDia() {
        return this.dia = x.nextInt(30);
    }
    
    int getMes() {
        return this.mes = x.nextInt(12);
    }
    
    int getAno() {
        return this.ano = 2018;
    }
}