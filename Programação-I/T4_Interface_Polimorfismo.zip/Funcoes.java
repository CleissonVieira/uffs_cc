import java.util.Scanner;
class Funcoes{
  Scanner escrever = new Scanner(System.in);
  void IndexMenuMain(){
    System.out.println("BLOG: O que você quer fazer?");
    System.out.println("1 - Novo post de notícia " );
    System.out.println("2 - Nova resenha de produto " );
    System.out.println("3 - Novo post de outros assuntos " );
    System.out.println("4 - Listar todas as postagens " );
    System.out.println("5 - Curtir uma postagem " );
    System.out.println("6 - Não curtir uma postagem " );
    System.out.println("0 - Sair:" );
    System.out.printf("\n ---> ");
  }

  void pause(){
    System.out.println("0 - Retornar menu");
    System.out.printf(" ---> ");
    int pause = escrever.nextInt();
  }

  void separa(){
    System.out.println("---------------------------------------------------------------------");
  }

  void limpaTela(){
    for (int i = 0; i < 30; ++i)
        System.out.println ();
  }
}
