public class News extends Post{
    private String source;

    public News(){
        super();
    }
    
    public News(String source) {
        super();
        this.source = source;
    }

    void setSource(String source){
        this.source = source;
    }

    String getSource(){
        return this.source;
    }

    public void show() {
        super.show();
        System.out.println("Fonte: " + this.source);
    }
}