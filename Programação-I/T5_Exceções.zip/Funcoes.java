import java.util.Scanner;
class Funcoes{
  Scanner escrever = new Scanner(System.in);
  void IndexMenuMain(){
    System.out.println("O que você quer fazer?");
    System.out.println("1 - Somar dois elementos: ");
    System.out.println("2 - Subtrair dois elementos: ");
    System.out.println("3 - Dividir dois elementos: ");
    System.out.println("4 - Multiplicar dois elementos: ");
    System.out.println("5 - Somar intervalo do vetor (1 a 9): ");
    System.out.println("6 - Criar vetor quantas posições? ");
    System.out.println("7 - Acessar uma posição do vetor (de 1 a 10): ");
    System.out.println("0 - Sair:" );
    System.out.printf("\n ---> ");
  }

  void pause(){
    System.out.println("0 - Retornar menu");
    System.out.printf(" ---> ");
    int pause = escrever.nextInt();
  }

  void separa(){
    System.out.println("---------------------------------------------------------------------");
  }

  void limpaTela(){
    for (int i = 0; i < 30; ++i)
        System.out.println ();
  }
}
