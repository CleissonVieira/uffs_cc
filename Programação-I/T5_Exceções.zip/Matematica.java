public class Matematica {

    public Matematica(){
        
    }
    //Questão 1
    public float somar(float x, float y) throws Exception{
        if(x == 0 || y == 0){
            throw new ParamZeroException();
        }else if(x + y == 0){
            throw new ResultadoZeroException();
        }else{
            return x + y;
        }
    }
    public float subtrair(float x, float y) throws Exception{
        if(x == 0 || y == 0){
            throw new ParamZeroException();
        }else if(x - y == 0){
            throw new ResultadoZeroException(); 
        }else{
            return x - y;
        }
    }   
    public float dividir(float x, float y) throws Exception{
        if(x == 0 || y == 0){
            throw new ParamZeroException();
        }else if(x / y == 0){
            throw new ResultadoZeroException();
        }else{
            return x / y;
        }
    } 
    public float multiplicar(float x, float y) throws Exception{
        if(x == 0 || y == 0){
            throw new ParamZeroException();
        }else if(x * y == 0){
            throw new ResultadoZeroException();
        }else{
            return x * y;
        }
    }
}