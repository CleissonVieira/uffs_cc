public class VetorVazioException extends Exception{

    
}