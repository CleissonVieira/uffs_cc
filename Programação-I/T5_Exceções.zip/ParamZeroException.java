public class ParamZeroException extends Exception{

    
}