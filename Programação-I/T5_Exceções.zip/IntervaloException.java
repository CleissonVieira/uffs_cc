public class IntervaloException extends Exception{

    
}