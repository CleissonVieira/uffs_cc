import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner escrever = new Scanner(System.in);
        Funcoes funcao = new Funcoes();
        Matematica mat = new Matematica();
        Vetor vet = new Vetor();
        int x = 1;
        do {
            try {
                do {
                    funcao.limpaTela();
                    funcao.IndexMenuMain();
                    x = escrever.nextInt();
                    switch (x) {

                            case 1:
                                mat.somar(escrever.nextFloat(), escrever.nextFloat());
                                break;
                            case 2:
                                mat.subtrair(escrever.nextFloat(), escrever.nextFloat());
                                break;
                            case 3:
                                mat.dividir(escrever.nextFloat(), escrever.nextFloat());
                                break;
                            case 4:
                                mat.multiplicar(escrever.nextFloat(), escrever.nextFloat());
                                break;
                            case 5:
                                System.out.println("Soma: " + Vetor.somaIntervalo(escrever.nextInt(), escrever.nextInt()));
                                break;
                            case 6:
                                vet.criar(escrever.nextInt());
                                break;
                            case 7  :
                                vet.posit(escrever.nextInt());
                                funcao.pause();
                                break;
                    }
                } while (x != 0);   
            } catch (ParamZeroException e) {
                System.out.println("Algum dos parametros é igual a zero...");
            } catch (ResultadoZeroException e) {
                System.out.println("Resultado igual zero...");
            } catch (VetorVazioException e) {
                System.out.println("Vetor preenchido com zeros...");
            } catch (IntervaloException e) {
                System.out.println("Intervalo inválido...");
            } catch (NegativeArraySizeException e){
                int vetor[] = new int[1];
                vetor[0] = 1;
                System.out.println("Primeira e única posição do vetor: " + vetor[0]);
                System.out.println("Entrada negativa...");
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Endereço acessado sem elemento...");
            } catch (Exception e) {
                System.out.println("Algum erro ocorreu...");
            }
            funcao.pause(); 
        } while (x != 0);    
    }
}