public class NegativeArraySizeException extends Exception{

    
}