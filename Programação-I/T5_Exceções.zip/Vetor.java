import java.util.Scanner;

public class Vetor {
    Scanner escrever = new Scanner(System.in);

    public Vetor(){

    }

    // Questão 2
    public static int somaIntervalo(int x, int y) throws Exception {
        int vet[] = new int[9];
        int soma = 0, cont = 0;
        for (int i = 0; i < 9; i++) {
            // Para entrar no caso de vetor preenchido com zeros
            // mude i + 1 por 0
            vet[i] = i + 1;
        }
        for (int j = 0; j < 9; j++) {
            if (vet[j] == 0) {
                cont++;
            }
        }
        if (x < 1 || y >= 10) {
            throw new IntervaloException();
        } else if (cont == 9) {
            throw new VetorVazioException();
        } else {
            for (int i = x; i < y; i++) {
                soma += vet[i];
            }
            return soma;
        }
    }

    //Questão 3
    public void criar(int x) throws Exception {
        if (x < 0) {
            throw new NegativeArraySizeException();
        } else {
            int vet[] = new int[x];
        }
    }

    //Questão 4
    public void posit(int x) throws Exception {
        int vet[] = new int[9];
        for (int i = 0; i <= 5; i++) {
            vet[i] = i + 1;
        }
        if(x > 5 || x < 1){
            throw new ArrayIndexOutOfBoundsException();
        }else{
            System.out.println("Valor do Index Informado: " + vet[x-1]);
        }
    }
}