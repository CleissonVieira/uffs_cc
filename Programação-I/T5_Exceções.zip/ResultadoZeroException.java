public class ResultadoZeroException extends Exception{

    
}