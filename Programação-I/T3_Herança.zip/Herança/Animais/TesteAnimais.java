class TesteAnimais {
    public static void main(String[] args) {

        Animal camelo = new Animal("Camelo", "Amarelo", "Terra", 150, 2, 4); 
        camelo.dados();

        Peixe tubarao = new Peixe("Tubarão", 300, 1.5);
        tubarao.dados();

        Mamifero urso = new Mamifero("Urso-do-canadá", "Vermelho", "Mel", 180, 0.5, 4);
        urso.dados();
        System.out.println("---------------------------------------");
    }
}