class Mamifero extends Animal{
    private String alimento;

    public Mamifero(String nome, String cor, String alimento, int comprimento, double velocidade, int patas){
        super(nome, cor, "Terra", comprimento, velocidade, patas);
        this.alimento = alimento;
    }

    void setAlimento(String alimento){
        this.alimento = alimento;
    }

    String getAlimento(){
        return this.alimento;
    }

    void dados() {
        System.out.println("---------------------------------------");
        System.out.println("Animal: " + getNome());
        System.out.println("Comprimento: " + getComprimento() + "cm");
        System.out.println("Patas: " + getPatas());
        System.out.println("Cor: " + getCor());
        System.out.println("Ambiente: " + getAmbiente());
        System.out.println("Velocidade: " + getVelocidade() + "m/s");
        System.out.println("Alimento: " + getAlimento());
    }
}