class Animal {
    private String nome;
    private int comprimento;
    private String cor;
    private String ambiente;
    private double velocidade;
    private int patas;

    public Animal(String nome, String cor, String ambiente, int comprimento, double velocidade, int patas){
        this.nome = nome;
        this.cor = cor;
        this.ambiente = ambiente;
        this.comprimento = comprimento;
        this.velocidade = velocidade;
        this.patas = patas;
    }

    void setNome(String nome){
        this.nome = nome;
    }
    String getNome() {
        return this.nome;
    }

    void setComprimento(int comprimento){
        this.comprimento = comprimento;
    }
    int getComprimento() {
        return this.comprimento;
    }

    void setPatas(int patas){
        this.patas = patas;
    }

    void setCor(String cor){
        this.cor = cor;
    }
    String getCor() {
        return this.cor;
    }

    void setAmbiente(String ambiente){
        this.ambiente = ambiente;
    }
    String getAmbiente() {
        return this.ambiente;
    }

    void setVelocidade(float velocidade){
        this.velocidade = velocidade;
    }

    double getVelocidade() {
        return this.velocidade;
    }
    
    int getPatas() {
        return this.patas;
    }
    

    void dados() {
        System.out.println("---------------------------------------");
        System.out.println("Animal: " + getNome());
        System.out.println("Comprimento: " + getComprimento() + "cm");
        System.out.println("Patas: " + getPatas());
        System.out.println("Cor: " + getCor());
        System.out.println("Ambiente: " + getAmbiente());
        System.out.println("Velocidade: " + getVelocidade() + "m/s");
    }
}