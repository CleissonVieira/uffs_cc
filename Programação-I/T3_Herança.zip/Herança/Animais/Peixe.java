class Peixe extends Animal{
    private String caracteristica;

    public Peixe(String nome, int comprimento, double velocidade){
        super(nome, "Cinzento", "Mar", comprimento, velocidade, 0);
        this.caracteristica = "Barbatanas e Cauda";
    }
 
    String getCaracteristica(){
        return this.caracteristica;
    }

    void dados(){
        System.out.println("---------------------------------------");
        System.out.println("Animal: " + getNome());
        System.out.println("Comprimento: " + getComprimento() + "cm");
        System.out.println("Patas: " + getPatas());
        System.out.println("Cor: " + getCor());
        System.out.println("Ambiente: " + getAmbiente());
        System.out.println("Velocidade: " + getVelocidade() + "m/s");
        System.out.println("Característica: " + getCaracteristica());
    }
}