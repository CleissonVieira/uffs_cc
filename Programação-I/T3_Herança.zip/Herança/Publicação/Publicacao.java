class Publicacao {
    private String nome;
    private double precoExemplar;
    protected double valorAnuidade;
    private Editora edit;

    public Publicacao(String nome, double precoExemplar, Editora edit){
        this.nome = nome;
        this.precoExemplar = precoExemplar;
        this.edit = edit;
    }   

    public Publicacao(Editora edit) {
        this.edit = edit;
    }

    public Publicacao(){
        
    }

    public void setNome(String nome){
        this.nome = nome;
    }

    public String getNome(){
        return this.nome;
    }
    
    public void setPrecoExemplar(double precoExemplar) {
        this.precoExemplar = precoExemplar;
    }
    
    public Double getPrecoExemplar() {
        return this.precoExemplar;
    }
    
    public void calcularAnuidade() {
        this.valorAnuidade = 12 * precoExemplar;
    }

    public void imprimirDados() {
        System.out.println("DADOS DA PUBLICAÇÃO");
        System.out.println("Nome: " + this.nome);
        System.out.println("Preço: R$" + this.precoExemplar);
        System.out.println("Valor Anual: R$" + this.valorAnuidade);
        System.out.println("Editora: " + this.edit.getNome());
        System.out.println("CNPJ: " + this.edit.getCnpj());
    }
}