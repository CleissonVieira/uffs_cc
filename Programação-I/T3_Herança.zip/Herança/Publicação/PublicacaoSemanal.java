class PublicacaoSemanal extends Publicacao{
    private double taxaEntrega; 

    public PublicacaoSemanal(String nome, double precoExemplar, Editora edit){
        super(nome, precoExemplar, edit);
    }

    public PublicacaoSemanal(Editora edit) {
        super(edit);
    }

    public PublicacaoSemanal(){
		super();
	}

    public void calcularAnuidade(){
        this.valorAnuidade = 52 * super.getPrecoExemplar();
    }

    public void calcularTaxaEntrega(){
        this.taxaEntrega = (super.getPrecoExemplar() * 0.05) * 52;
    }

    public void imprimirDados() {
        System.out.println("\nPUBLICAÇÃO SEMANAL");
        super.imprimirDados();
        System.out.println("Taxa de entrega: R$" + this.taxaEntrega);
    }
}