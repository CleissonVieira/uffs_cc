class Editora {
    private String nome;
    private String cnpj;

    public Editora(String nome, String cnpj){
        this.nome = nome;
        this.cnpj = cnpj;
    }

    public Editora(){
        
    }

    public void setNome(String nome){
        this.nome = nome;
    }
    public String getNome(){
        return this.nome;
    }

    public void setCnpj(String cnpj){
        this.cnpj = cnpj;
    }
    public String getCnpj(){
        return this.cnpj;
    }
}