import java.util.*;

class Main {
    public static void main(String[] args) {
        Scanner escrever = new Scanner(System.in);
        Editora edit = new Editora("São Paulo", "1854595-58");

        System.out.println("PUBLICAÇÃO SEMANAL");
        PublicacaoSemanal pubse = new PublicacaoSemanal(edit);

        System.out.println("Nome: ");
        pubse.setNome(escrever.next());

        System.out.println("Preço: ");
        pubse.setPrecoExemplar(escrever.nextDouble());

        pubse.calcularAnuidade();
        pubse.calcularTaxaEntrega();
        pubse.imprimirDados();
    }
}