class Site::Profile::DashboardController < Site::ProfileController
    def index
        #
    end
end
