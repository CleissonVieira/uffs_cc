class Site::ProfileController < SiteController
  layout "profile"

end
