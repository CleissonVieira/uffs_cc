class SiteController < ApplicationController
  layout "site"
end
