class Backoffice::DashboardController < BackofficeController
  
  def index
  end
end
