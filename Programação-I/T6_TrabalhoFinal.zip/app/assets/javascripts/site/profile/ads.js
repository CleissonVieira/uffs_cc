$(function(){
    $('.datepicker').datepicker();
});