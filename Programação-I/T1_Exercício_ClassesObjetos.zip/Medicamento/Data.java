class Data{
  int dia;
  int mes;
  int ano;

  String formata(){
    return new String(this.dia+"/"+this.mes+"/"+this.ano);
  }
}
