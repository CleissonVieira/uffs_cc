import java.util.Scanner;

class Medicamento{
    String nome;
    double precoVenda;
    Data dataValidade = new Data();
    Laboratorio laboratorio = new Laboratorio( "LNM", "Laboratorio Novo Mundo", "78.425.986/0036-15",
                                      "563.056.977.805", "Av. Brasil, Centro, 157", "0800 556 987");;
    boolean receitaObrigatoria;
    int qtdEstoque, sn = 0;

    Scanner entrada = new Scanner(System.in);

    void reajustarPrecoVenda(double percentual){
      this.precoVenda = this.precoVenda * (percentual / 100);
    }

    void vender(int quantidade){
      if(this.receitaObrigatoria){
        System.out.println("Esse medicamento só pode ser vendido com receita.");
        System.out.printf("Possui receita?  |1 - SIM | 2 - NÃO| ");
        sn = entrada.nextInt();
        if(sn == 1){
          this.qtdEstoque -= quantidade;
        }
        else if(sn == 2){
          System.out.println("Venda não atorizada!");
        }
      }
    }

    void comprar(int quantidade){
      this.qtdEstoque += quantidade;
    }

    void mostraLab(){
      System.out.println("\nINFORMAÇÕES LABORATÓRIO: ");
      System.out.println("Nome fantasia: " + this.laboratorio.nomeFantasia);
      System.out.println("Razao social: " + this.laboratorio.razaoSocial);
      System.out.println("CNPJ: " + this.laboratorio.cnpj);
      System.out.println("Inscrição Estadual: " + this.laboratorio.inscEstadual);
      System.out.println("Endereço: " + this.laboratorio.endereco);
      System.out.println("Telefone: " + this.laboratorio.telefone);
    }

    void mostra(){
      System.out.println("\nMEDICAMENTO:");
      System.out.println("Nome: " + this.nome);
      System.out.println("Preço: R$ " + this.precoVenda);
      System.out.println("Validade: " + this.dataValidade.formata());
      System.out.println("Receita: " + this.receitaObrigatoria);
      System.out.println("Quantidade em estoque: " + this.qtdEstoque);
    }

    void menu(){
      System.out.println("\nMENU PRINCIPAL");
      System.out.println("1 - Mostrar Produto:");
      System.out.println("2 - Mostrar Laboratório:");
      System.out.println("3 - Reajustar Preço:");
      System.out.println("4 - Cadastrar Produto:");
      System.out.println("5 - Comprar Produto:");
      System.out.println("6 - Vender Produto:");
      System.out.println("0 - Encerrar.");
    }

    void limpaTela(){
      for (int i = 0; i < 30; ++i)
          System.out.println ();
    }

    void traco(){
      System.out.printf("-----------------------------------------------------------------------------");

    }

    void cadastro(){
      System.out.println("\nCADASTRO DE PRODUTO");
      System.out.printf("Nome: ");
      nome = entrada.nextLine();
      System.out.printf("Preço de Venda: R$");
      precoVenda = entrada.nextDouble();
      System.out.println("Data de Validade: ");
      System.out.printf("Dia: ");
      dataValidade.dia = entrada.nextInt();
      System.out.printf("Mês: ");
      dataValidade.mes = entrada.nextInt();
      System.out.printf("Ano: ");
      dataValidade.ano = entrada.nextInt();
      System.out.println("Receita Obrigatória? ");
      System.out.printf("|1 - SIM | 2 - NÂO|  ");
      sn = entrada.nextInt();
      if(sn == 1){
        receitaObrigatoria = true;
      }
      else if(sn == 2){
        receitaObrigatoria = false;
      }
      System.out.printf("Quantidade em Estoque: ");
      qtdEstoque = entrada.nextInt();
    }
}
