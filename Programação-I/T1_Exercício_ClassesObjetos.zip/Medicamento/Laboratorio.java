class Laboratorio{
    String nomeFantasia;
    String razaoSocial;
    String cnpj;
    String inscEstadual;
    String endereco;
    String telefone;

    public Laboratorio( String nomeFantasia, String razaoSocial, String cnpj,
                        String inscEstadual, String endereco, String telefone){
          this.nomeFantasia = nomeFantasia;
          this.razaoSocial = razaoSocial;
          this.cnpj = cnpj;
          this.inscEstadual = inscEstadual;
          this.endereco = endereco;
          this.telefone = telefone;
    }

}
