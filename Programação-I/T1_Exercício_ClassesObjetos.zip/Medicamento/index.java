import java.util.Scanner;
class index{
    public static void main(String[] args){
    int x, stop, cv;
    double reajuste;
    Scanner entrada = new Scanner(System.in);
    Medicamento medicamento = new Medicamento();
    do{
      medicamento.limpaTela();
      medicamento.menu();
      x = entrada.nextInt();
      switch(x){
        case 1:{
          medicamento.traco();
          medicamento.mostra();
          medicamento.traco();
          System.out.printf("\n0 - retorna ao menu: ");
          stop = entrada.nextInt();
          medicamento.traco();
          break;
        }
        case 2:{
          medicamento.traco();
          medicamento.mostraLab();
          medicamento.traco();
          System.out.printf("\n0 - retorna ao menu: ");
          stop = entrada.nextInt();
          medicamento.traco();
          break;
        }
        case 3:{
          medicamento.traco();
          System.out.printf("\nPorcentagem a ser reajustada: ");
          reajuste = entrada.nextFloat();
          medicamento.reajustarPrecoVenda(reajuste);
          medicamento.traco();
          break;
        }
        case 4:{
          medicamento.traco();
          medicamento.cadastro();
          System.out.println("Cadastrado com sucesso!");
          break;
        }
        case 5:{
          medicamento.traco();
          System.out.println("\nQuantidade a ser comprada:");
          cv = entrada.nextInt();
          medicamento.comprar(cv);
          medicamento.traco();
          break;
        }
        case 6:{
          medicamento.traco();
          System.out.println("\nQuantidade a ser vendida:");
          cv = entrada.nextInt();
          medicamento.vender(cv);
          medicamento.traco();
          break;
        }
        case 0:{
          break;
        }
      }
    } while (x != 0);

  }
}
