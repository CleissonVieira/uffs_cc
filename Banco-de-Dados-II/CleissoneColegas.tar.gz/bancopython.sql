--acessar mysql: mysql -h localhost -u root -p
--Criar banco e dados: create database <name>;
--Criar usuario: CREATE USER 'teste'@'localhost' IDENTIFIED BY 'password';
--Dar privilégio ao user: GRANT ALL PRIVILEGES ON * . * TO 'teste'@'localhost';
--Validar as alterações: FLUSH PRIVILEGES;
--acessar banco criado: use <nome do banco>;

create table account_A(
    id int,
    nome varchar(50),
    balance int,
    PRIMARY KEY (id)
);

create table account_B(
    id int,
    nome varchar(50),
    balance int,
    PRIMARY KEY (id)
);

insert into account_A (id, nome, balance) values (1, 'teste1', 100);
insert into account_B (id, nome, balance) values (2, 'teste2', 200);