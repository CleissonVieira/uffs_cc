#include <stdlib.h>
#include <stdio.h>

void vetor_malloc(int *vetor, int tam){
	int i;
	printf("Digite  sequencias de 4 bytes de numeros seguidos de enter:\n");
	for(i=0; i<tam; i++){
		scanf("%d", (vetor+i));
		__fpurge(stdin);
	}
	printf("\n");
}

int main(){
	int *vetor, i, tam;
	printf("Digite tamanho do vetor\n");
	scanf("%d", &tam);
	__fpurge(stdin);
	vetor = (int *) malloc(tam*sizeof(int));
	vetor_malloc(&*vetor, tam);
	for(i=0; i<tam; i++){
		printf("Posicao = %d Conteudo = %d\n", i, *(vetor+i));
	}
	free(vetor);
	return 0;
}