#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct estudante{
   char nome[50];
   char endereco[100];
   int matricula;
} estudante;

void funcao(estudante *vetor, int tam, int i){
   printf("Digite os dados:\n\n");
   __fpurge(stdin);
   for(i = 0; i < tam; i++){
      printf("%d Estudante\n", i+1);
      printf("Nome: ");
      fgets((vetor+i)->nome, 50, stdin);
      printf("Endereco: ");
      fgets((vetor+i)->endereco, 100, stdin);
      printf("Matricula: ");
      scanf("%d", &((vetor+i)->matricula));
      __fpurge(stdin);
      printf("\n");
   }
}

int main(){
   estudante *vetor;
   int tam, i;
   printf("Digite a quantidade de Estudantes:\n");
   scanf("%d", &tam);
   __fpurge(stdin);
   vetor = (estudante*)malloc(tam*sizeof(estudante));
   funcao(&*vetor, tam, i);
   system("clear");
   printf("Dados Armazenados:\n\n");
   for(i = 0; i < tam; i++){
      printf("%d Estudante\n", i+1);
      printf("Nome: %s", (vetor+i)->nome);
      printf("Endereço: %s", (vetor+i)->endereco);
      printf("Matrícula: %d\n\n", (vetor+i)->matricula);
   }
   free(vetor);
   return 0;
}