#include <stdlib.h>
#include <stdio.h>

int* uniao(int v1[], int n1, int v2[], int n2){
	int *v3, i, j;
	v3 = (int *) malloc((n1+n2)*sizeof(int));

	for(i=0; i<n1; i++){
		*(v3+i)=*(v1+i);
	}

	for(j=0; j<n2; j++, i++){
		*(v3+i)=*(v2+j);
	}

	return v3;
}

int main(){
	int *v1, *v2, n1=4, n2=6, i, *v3, j;
	v1 = (int *) malloc(n1*sizeof(int));
	v2 = (int *) malloc(n2*sizeof(int));
	printf("Digite 4 sequencias de numeros seguido de enter:\n");
	for(i=0; i<n1; i++){
		scanf("%d", (v1+i));
	}

	printf("Digite 6 sequencias de numeros seguido de enter:\n");
	for(i=0; i<n2; i++){
		scanf("%d", (v2+i));
	}

	v3=uniao(v1, n1, v2, n2);
	printf("Unicao dos vetores:\n");
	for(i=0; i<(n1+n2); i++){
		printf("%d\n", *(v3+i));
	}
	free(v1);
	free(v2);
	free(v3);
	return 0;
}
