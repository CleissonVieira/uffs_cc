<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Questão 2</title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <?php
            $Sala = array(
                "1" => array("Nome" => "Luana", "NP1" => "6.2", "NP2" => "5.8"),
                "2" => array("Nome" => "Sabrina", "NP1" => "7", "NP2" => "3"),
                "3" => array("Nome" => "Willian", "NP1" => "3.9", "NP2" => "2"),
                "4" => array("Nome" => "Ricardo", "NP1" => "9", "NP2" => "0"),
                "5" => array("Nome" => "Nicolas", "NP1" => "2", "NP2" => "6"),
                "6" => array("Nome" => "Barbara", "NP1" => "1.1", "NP2" => "7"),
                "7" => array("Nome" => "Thalia", "NP1" => "8", "NP2" => "5"),
                "8" => array("Nome" => "Beatriz", "NP1" => "5", "NP2" => "3"),
                "9" => array("Nome" => "Cleisson", "NP1" => "10", "NP2" => "10"),
                "10" => array("Nome" => "Tayane", "NP1" => "9.5", "NP2" => "9")
            );
        ?>
        <table id="playlistTable">
            <tr>
                <th>Aluno</th>
                <th>Prova 1</th>
                <th>Prova 2</th>
            </tr>
            <?php
                //$aluno recebe a primeira posição do array $Sala e a cada foreach incrementa +1 na posição
                foreach($Sala as $aluno){ 
                    echo "<tr><td>".$aluno['Nome']."</td>";
                    echo "<td>".$aluno['NP1']."</td>";
                    echo "<td>".$aluno['NP2']."</td></tr>"; 
                }
            ?>
        </table>
    </body>
</html>

