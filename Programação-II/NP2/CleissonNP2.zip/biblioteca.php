<?php
    //Função recebe a hora do dia e retorna um cumprimento (bom dia, boa tarde, boa noite, boa madrugada)
	function Cumprimento($hora){
        if($hora >= 0 && $hora < 6){
            $cumprimento = 'Boa madrugada, ';
        }elseif($hora >= 6 && $hora < 13){
            $cumprimento = 'Bom dia, ';
        }else if($hora >= 13 && $hora < 18){
            $cumprimento = 'Boa tarde, ';
        }else if($hora >= 18 && $hora < 23){
            $cumprimento = 'Boa noite, ';
        }
        return $cumprimento;
    }
    //Função recebe um dia da semana e retorna o respectivo nome do dia por extenso (em português)
    function DiaSemana($dia){
        if($dia == 7){
            $dSemana = ' (Domingo)';
        }else if($dia == 1){
            $dSemana = ' (Segunda-Feira)';
        }else if($dia == 2){
            $dSemana = ' (Terça-Feira)';
        }else if($dia == 3){
            $dSemana = ' (Quarta-Feira)';
        }else if($dia == 4){
            $dSemana = ' (Quinta-Feira)';
        }else if($dia == 5){
            $dSemana = ' (Sexta-Feira)';
        }else if($dia == 6){
            $dSemana = ' (Sábado)';
        }
        return $dSemana;
    }
?>