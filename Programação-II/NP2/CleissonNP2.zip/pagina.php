<?php
    include "biblioteca.php";
    echo Cumprimento(date('G'));
    echo 'hoje é '.date('d/m/y').DiaSemana(date('N'));
?>